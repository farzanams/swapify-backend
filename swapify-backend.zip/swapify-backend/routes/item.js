const express = require('express');
const router = express.Router();
const Item = require('../models/Item');

router.post('/create', async (req, res) => {
  const { title, description, category, imageUrl, owner } = req.body;
  try {
    const item = await Item.create({ title, description, category, imageUrl, owner });
    res.json({ message: 'Item created successfully', item });
  } catch (err) {
    res.status(400).json({ error: 'Failed to create item' });
  }
});
// GET all items
router.get('/', async (req, res) => {
  try {
    const items = await Item.find().populate('owner', 'name email');
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch items' });
  }
});

module.exports = router;
