const express = require('express');
const router = express.Router();
const SwapRequest = require('../models/SwapRequest');

// Create a swap request
router.post('/request', async (req, res) => {
  const { fromItem, toItem, message } = req.body;
  try {
    const swap = new SwapRequest({ fromItem, toItem, message });
    await swap.save();
    res.json({ message: 'Swap request sent', swap });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create swap request' });
  }
});

// Get all incoming swap requests for a specific item
router.get('/incoming/:itemId', async (req, res) => {
  try {
    const requests = await SwapRequest.find({ toItem: req.params.itemId })
      .populate('fromItem')
      .populate('toItem');
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch swap requests' });
  }
});

// Get all swap requests
router.get('/', async (req, res) => {
  try {
    const swaps = await SwapRequest.find()
      .populate('fromItem')
      .populate('toItem');
    res.json(swaps);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch swap requests' });
  }
});

// Accept or reject a swap (with validation)
router.patch('/:id', async (req, res) => {
  const { status } = req.body;

  try {
    const swap = await SwapRequest.findById(req.params.id);

    if (!swap) {
      return res.status(404).json({ message: 'Swap request not found' });
    }

    if (swap.status === 'accepted') {
      return res.status(400).json({ message: 'Swap request already accepted' });
    }

    if (swap.status === 'rejected') {
      return res.status(400).json({ message: 'Swap request already rejected' });
    }

    swap.status = status;
    await swap.save();

    res.json({ message: `Swap ${status}`, swap });
  } catch (err) {
    console.error('Error updating swap:', err);
    res.status(500).json({ error: 'Failed to update swap request' });
  }
});



module.exports = router;
