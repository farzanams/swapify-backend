const mongoose = require('mongoose');

const swapRequestSchema = new mongoose.Schema({
  fromItem: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
  toItem: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
  message: { type: String },
  status: { type: String, enum: ['pending', 'accepted', 'rejected'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('SwapRequest', swapRequestSchema);
